<?php

namespace App\Models;

use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Libro extends Model
{
    use HasFactory;

    public static function createLibro(Request $request) {

        $book = new Libro();
        $book->titulo = $request->input('titulo');
        $book->autor = $request->input('autor');
        $book->ano_publicacion = $request->input('ano_publicacion');
        $book->genero = $request->input('genero');
        $book->disponible = $request->input('disponible') === 'on' ? true : false;
        $book->save();

        return $book->id;
    }

    public static function showLibros() {
        return Libro::all();
    }

    public static function updateLibro($id, Request $request){
        $book = Libro::find($id);
        $book->titulo = $request->input('titulo');
        $book->autor = $request->input('autor');
        $book->ano_publicacion = $request->input('ano_publicacion');
        $book->genero = $request->input('genero');
        $book->disponible = $request->input('disponible') === 'on' ? true : false;
        $book->save();
    }

    public static function deleteLibro($id) {
        $book = Libro::find($id);
        $book->delete();
    }

    public static function findLibroID($id) {
        return Libro::find($id);
    }
}
