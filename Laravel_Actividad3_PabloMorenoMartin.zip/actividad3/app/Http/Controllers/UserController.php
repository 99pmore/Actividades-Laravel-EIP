<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    // @auth
    public function showLoans() {
        $user = Auth::user();
        $loans = $user->loans;

        return view('users.loans', compact('loans'));
    }
    // @endauth
}
