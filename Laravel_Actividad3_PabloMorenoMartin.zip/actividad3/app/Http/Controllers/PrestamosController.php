<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Libro;
use App\Models\Prestamo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;

class PrestamosController extends Controller
{
    public function createPrestamo(Request $request) {
        Prestamo::createPrestamo($request);

        $book = Libro::findLibroID($request->input('book_id'));
        $book->disponible = false;
        $book->save();
        
        return Redirect::to('/showPrestamos');
    }

    public function showPrestamos() {
        $loans = Prestamo::showPrestamos();
        return view('showPrestamos', compact('loans'));
    }

    public function updatePrestamo(Request $request) {
        $id = Session::get('id');
        Prestamo::updatePrestamo($id, $request);
        return Redirect::to('/showPrestamos');
    }

    public function deletePrestamo($id) {

        $loan = Prestamo::findPrestamoID($id);
        
        $book = Libro::findLibroID($loan->book_id);
        $book->disponible = true;
        $book->save();

        Prestamo::deletePrestamo($id);

        return Redirect::to('/showPrestamos');
    }

    public function showCreatePrestamo() {
        $books = Libro::showLibros();
        $users = User::showUsers();
        return view('createPrestamo', compact('books', 'users'));
    }

    public function showUpdatePrestamo($id) {
        $loan = Prestamo::findPrestamoID($id);
        Session::flash('id', $id);
        $books = Libro::showLibros();
        return view('updatePrestamo', compact('loan','books'));
    }

    public function showPrestamoDetail($id) {
        $loan = Prestamo::findPrestamoID($id);
        Session::flash('id', $id);

        $book = Libro::findLibroID($loan->book_id);

        $user = User::findUserID($loan->user_id);

        return view('showPrestamo', compact('loan', 'book', 'user'));
    }

    public function endPrestamo($id) {

        $loan = Prestamo::findPrestamoID($id);
        
        $book = Libro::findLibroID($loan->book_id);
        $book->disponible = true;
        $book->save();
    
        Prestamo::endPrestamo($id);
    
        return Redirect::to('/showPrestamos');
    }
}
