<?php

namespace App\Http\Controllers;

use App\Models\Libro;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;

class LibrosController extends Controller
{
    public function createLibro(Request $request) {
        $id = Libro::createLibro($request);
        return view('createLibro_OK' , ['id' => $id] );
    }

    public function showLibros() {
        $books = Libro::showLibros();
        return view('showLibros')->with('books', $books);
    }

    public function updateLibro(Request $request) {
        $id = Session::get('id');
        Libro::updateLibro($id, $request);
        return Redirect::to('/showLibros');
    }

    public function deleteLibro($id) {
        Libro::deleteLibro($id);
        return Redirect::to('/showLibros');
    }

    public function showCreateLibro() {
        return view('createLibro');
    }

    public function showUpdateLibro($id) {
        $book = Libro::findLibroID($id);
        Session::flash('id', $id);
        return view('updateLibro', compact('book'));
    }

    public function showLibroDetail($id) {
        $book = Libro::findLibroID($id);
        Session::flash('id', $id);
        return view('showLibro', compact('book'));
    }

}
