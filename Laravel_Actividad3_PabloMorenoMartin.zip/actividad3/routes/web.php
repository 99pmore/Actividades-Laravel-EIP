<?php

use App\Http\Controllers\LibrosController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::post('/createLibro', [LibrosController::class, 'createLibro'])->name('createLibro')->middleware('auth');
Route::get('/showLibros', [LibrosController::class, 'showLibros'])->name('showLibros');
Route::post('/updateLibro', [LibrosController::class, 'updateLibro'])->name('updateLibro')->middleware('auth');
Route::get('/deleteLibro/{id}', [LibrosController::class, 'deleteLibro'])->middleware('auth');

Route::get('/showCreateLibro', [LibrosController::class, 'showCreateLibro'])->name('showCreateLibro')->middleware('auth');
Route::get('/showLibroDetail/{id}', [LibrosController::class, 'showLibroDetail']);
Route::get('/showUpdateLibro/{id}', [LibrosController::class, 'showUpdateLibro'])->middleware('auth');

Route::post('/createPrestamo', [PrestamosController::class, 'createPrestamo'])->name('createPrestamo')->middleware('auth');
Route::get('/showPrestamos', [PrestamosController::class, 'showPrestamos'])->name('showPrestamos')->middleware('auth');
Route::post('/updatePrestamo', [PrestamosController::class, 'updatePrestamo'])->name('updatePrestamo')->middleware('auth');
Route::get('/deletePrestamo/{id}', [PrestamosController::class, 'deletePrestamo'])->middleware('auth');

Route::get('/showCreatePrestamo', [PrestamosController::class, 'showCreatePrestamo'])->middleware('auth');
Route::get('/showPrestamoDetail/{id}', [PrestamosController::class, 'showPrestamoDetail'])->middleware('auth');
Route::get('/showUpdatePrestamo/{id}', [PrestamosController::class, 'showUpdatePrestamo'])->middleware('auth');
Route::get('/endPrestamo/{id}', [PrestamosController::class, 'endPrestamo'])->middleware('auth');


Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified',
])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');
});
