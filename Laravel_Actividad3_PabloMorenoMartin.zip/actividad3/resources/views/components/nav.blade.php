<nav class="bg-slate-700 text-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-center items-center h-16">
            <div class="flex justify-center items-center w-full h-full">
                <!-- Logo -->
                <div class="shrink-0 flex items-center">
                    <a href="{{ route('dashboard') }}">
                        <x-application-mark class="block h-9 w-auto" />
                    </a>
                </div>
    
                <!-- Navigation links -->
                <div class="space-x-8 sm:-my-px sm:ml-10 sm:flex h-full flex items-center">
                    <x-nav-link href="{{ route('showLibros') }}" :active="request()->routeIs('showLibros')" class="text-lg h-full">
                        {{ __('Ver libros') }}
                    </x-nav-link>
                    @auth
                        <x-nav-link href="{{ route('showCreateLibro') }}" :active="request()->routeIs('showCreateLibro')" class="text-lg h-full">
                            {{ __('Añadir libro') }}
                        </x-nav-link>
                        <x-nav-link href="{{ route('showPrestamos') }}" :active="request()->routeIs('showPrestamos')" class="text-lg h-full">
                            {{ __('Ver Préstamos') }}
                        </x-nav-link>
                        <div class="bg-white rounded-md h-8 flex justify-center items-center px-1.5">    
                            <x-nav-link href="{{ route('dashboard') }}" :active="request()->routeIs('dashboard')" class="text-sm text-black hover:text-sm hover:no-underline">
                                {{ __('Dashboard') }}
                            </x-nav-link>
                        </div>
                    @else
                        <div class="bg-white rounded-md h-8 flex justify-center gap-6 items-center px-1.5">
                            <x-nav-link href="{{ route('login') }}" :active="request()->routeIs('login')" class="text-black text-sm hover:text-sm hover:no-underline">
                                {{ __('Iniciar sesión') }}
                            </x-nav-link>
                            <x-nav-link href="{{ route('register') }}" :active="request()->routeIs('register')" class="text-black text-sm hover:text-sm hover:no-underline">
                                {{ __('Registrarse') }}
                            </x-nav-link>
                        </div>
                    @endauth
                </div>
            </div>
        </div>
    </div>
</nav>