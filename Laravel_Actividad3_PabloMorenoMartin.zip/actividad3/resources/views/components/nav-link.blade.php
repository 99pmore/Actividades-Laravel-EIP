@props(['active'])

@php
$classes = ($active ?? false)
            ? 'text-lg hover:text-xl inline-flex items-center px-1 pt-1 border-b-2 border-indigo-400 leading-5 text-white transition duration-150 ease-in-out'
            : 'text-lg hover:text-xl inline-flex items-center px-1 pt-1 border-b-2 border-transparent leading-5 text-white transition duration-150 ease-in-out';
@endphp

<a {{ $attributes->merge(['class' => $classes]) }}>
    {{ $slot }}
</a>
