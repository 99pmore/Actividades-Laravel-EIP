@extends('app')

@section('title', 'Editar libro')

@section('content')

    <form action={{ route('updateLibro') }} method="POST" class="w-full p-6 flex justify-center items-center gap-5 flex-col">
        @csrf

        <label for="titulo">Título:</label>
        <input type="text" name="titulo" value="{{ $book->titulo }}" class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">
        <label for="autor">Autor:</label>
        <input type="text" name="autor" value="{{ $book->autor }}" class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">
        <label for="ano_publicacion">Año de publicación:</label>
        <input type="text" name="ano_publicacion" value="{{ $book->ano_publicacion }}" class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">
        <label for="genero">Género:</label>
        <input type="text" name="genero" value="{{ $book->genero }}" class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">
        <label for="disponible">Disponible:</label>
        <input type="checkbox" name="disponible" {{ $book->disponible ? 'checked' : '' }} class="w-5 h-5 border border-solid rounded-md border-emerald-600 outline-emerald-600">

        <input type="submit" value="Actualizar" class="mt-5 cursor-pointer text-lg py-2 px-4 text-white bg-emerald-600 rounded-xl hover:bg-emerald-800 hover:transition-all 0.3s">
    </form>

@endsection