@extends('app')

@section('title', $book->titulo)

@section('content')

    <div class="p-6 w-full flex justify-center items-center flex-col gap-8">
        <div class="w-full flex justify-center items-center flex-col gap-4">
            <h2 class="text-4xl font-bold">{{ $book->titulo }}</h2>
            <h3 class="text-2xl font-semibold">{{ $book->autor }}</h3>
        </div>
    
        <div class="w-full flex justify-center items-center flex-col gap-2">
            <p class="text-lg">Año de publicación: {{ $book->ano_publicacion }}</p>
            <p class="text-lg">Género: {{ $book->genero }}</p>
            <p class="text-lg">Disponible: {{ $book->disponible ? 'Sí' : 'No' }}</p>
        </div>

        @if ($book->disponible)
            <a class="text-lg py-2 px-4 text-white bg-emerald-600 rounded-xl hover:bg-emerald-800 hover:transition-all 0.3s" href="http://127.0.0.1:8000/showCreatePrestamo">Reservar</a>
        @else
            <a class="text-lg py-2 px-4 text-white bg-gray-400 rounded-xl cursor-not-allowed" href="" title="Libro no disponible actualmente">Reservar</a>
        @endif
    </div>

@endsection