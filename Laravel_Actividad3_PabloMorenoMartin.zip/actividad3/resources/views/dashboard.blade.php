<x-app-layout>
    <x-welcome />
</x-app-layout>
