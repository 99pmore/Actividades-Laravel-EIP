

<?php $__env->startSection('title', 'Préstamo'); ?>

<?php $__env->startSection('content'); ?>

    <div class="p-6 w-full flex justify-center items-center flex-col gap-8">
        <div class="w-full flex justify-center items-center flex-col gap-4">
            <h2 class="text-3xl font-bold"><?php echo e($book->titulo); ?></h2>
            <h2 class="text-2xl font-semibold"><?php echo e($book->autor); ?></h2>
        </div>
    
        <div class="w-full flex justify-center items-center flex-col gap-2">
            <h3 class="text-2xl font-semibold">Reservado por: <?php echo e($loan->user_id); ?></h3>
            <br>
            <p class="text-lg">Desde: <?php echo e($loan->fecha_prestamo); ?></p>
            <p class="text-lg">Hasta: <?php echo e($loan->fecha_devolucion); ?></p>
            <br>
            <p class="text-lg">Devuelto: <?php echo e($loan->devuelto ? 'Sí' : 'No'); ?></p>
        </div>

        <?php if(!$loan->devuelto): ?>
            <a class="text-lg py-2 px-4 text-white bg-emerald-600 rounded-xl hover:bg-emerald-800 hover:transition-all 0.3s" href="http://127.0.0.1:8000/endPrestamo/<?php echo e($loan->id); ?>">Devolver</a>
        <?php else: ?>
            <a class="text-lg py-2 px-4 text-white bg-gray-400 rounded-xl cursor-not-allowed" href="" title="El libro ya ha sido devuelto">Devolver</a>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moren\Documents\Master EIP\9. Programaciones de Aplicaciones Web con Laravel\Actividades\actividad_2\resources\views/showPrestamo.blade.php ENDPATH**/ ?>