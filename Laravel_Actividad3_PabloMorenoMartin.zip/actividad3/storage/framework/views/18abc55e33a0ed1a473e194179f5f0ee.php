

<?php $__env->startSection('title', 'Ver préstamos'); ?>

<?php $__env->startSection('content'); ?>

    <div class="flex flex-col gap-12">
        <a href="/showCreatePrestamo" class="w-44 text-center text-lg py-2 px-4 text-white bg-emerald-600 rounded-xl hover:bg-emerald-800 hover:transition-all 0.3s">Añadir préstamo</a>

        <div>
            <?php if($loans->isEmpty()): ?>

                <p>No hay préstamos</p>

            <?php else: ?>
            
                <table class="w-full border-spacing-6 border-separate">
                    <thead class="text-left">
                        <tr>
                            <th>Usuario</th>
                            <th>Libro</th>
                            <th>Fecha de préstamo</th>
                            <th>Fecha de devolución</th>
                            <th>Acción</th>
                            <th>Detalles</th>
                            <th>Marcar como devuelto</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php echo $__env->renderEach('components.tablePrestamo', $loans, 'loan'); ?>
                    </tbody>
                </table>

            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moren\Documents\Master EIP\9. Programaciones de Aplicaciones Web con Laravel\Actividades\actividad_2\resources\views/showPrestamos.blade.php ENDPATH**/ ?>