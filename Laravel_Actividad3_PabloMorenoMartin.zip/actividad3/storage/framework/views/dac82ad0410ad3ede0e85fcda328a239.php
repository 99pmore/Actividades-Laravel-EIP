

<?php $__env->startSection('title', 'Ver libros'); ?>

<?php $__env->startSection('content'); ?>

    <?php if($books->isEmpty()): ?>

        <p>No hay libros añadidos</p>
        
    <?php else: ?>

        <table class="w-full border-spacing-6 border-separate">
            <thead class="text-left">
                <tr>
                    <th>Título</th>
                    <th>Autor</th>
                    <th>Año de publicación</th>
                    <th>Género</th>
                    <th>Disponible</th>
                    <th>Acción</th>
                    <th>Detalles</th>
                </tr>
            </thead>
            <tbody>
                <?php echo $__env->renderEach('components.table', $books, 'book'); ?>
            </tbody>
        </table>

    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moren\Documents\Master EIP\9. Programaciones de Aplicaciones Web con Laravel\Actividades\actividad_2\resources\views/showLibros.blade.php ENDPATH**/ ?>