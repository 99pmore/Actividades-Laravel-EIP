

<?php $__env->startSection('title', 'Editar libro'); ?>

<?php $__env->startSection('content'); ?>

    <form action=<?php echo e(route('updateLibro')); ?> method="POST" class="w-full p-6 flex justify-center items-center gap-5 flex-col">
        <?php echo csrf_field(); ?>

        <label for="titulo">Título:</label>
        <input type="text" name="titulo" value="<?php echo e($book->titulo); ?>" class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">
        <label for="autor">Autor:</label>
        <input type="text" name="autor" value="<?php echo e($book->autor); ?>" class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">
        <label for="ano_publicacion">Año de publicación:</label>
        <input type="text" name="ano_publicacion" value="<?php echo e($book->ano_publicacion); ?>" class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">
        <label for="genero">Género:</label>
        <input type="text" name="genero" value="<?php echo e($book->genero); ?>" class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">
        <label for="disponible">Disponible:</label>
        <input type="checkbox" name="disponible" <?php echo e($book->disponible ? 'checked' : ''); ?> class="w-5 h-5 border border-solid rounded-md border-emerald-600 outline-emerald-600">

        <input type="submit" value="Actualizar" class="mt-5 cursor-pointer text-lg py-2 px-4 text-white bg-emerald-600 rounded-xl hover:bg-emerald-800 hover:transition-all 0.3s">
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moren\Documents\Master EIP\9. Programaciones de Aplicaciones Web con Laravel\Actividades\actividad_2\resources\views/updateLibro.blade.php ENDPATH**/ ?>