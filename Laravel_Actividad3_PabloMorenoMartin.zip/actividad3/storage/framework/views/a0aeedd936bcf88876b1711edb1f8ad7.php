

<?php $__env->startSection('title', 'Añadir préstamo'); ?>

<?php $__env->startSection('content'); ?>

    <form action=<?php echo e(route('createPrestamo')); ?> method="POST" class="w-full p-6 flex justify-center items-center gap-5 flex-col">
        <?php echo csrf_field(); ?>

        <label for="user_id">Usuario:</label>
        <select name="user_id" required class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">
            <?php if($users->isEmpty()): ?>

                <option value="" selected disabled>No hay usuarios</option>
            
            <?php else: ?>

                <option value="" selected disabled>Selecciona un usuario:</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value=<?php echo e($user->id); ?>><?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
            <?php endif; ?>
        </select>
        <label for="book_id">Libro:</label>
        <select name="book_id" required class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">
            <?php if($books->isEmpty()): ?>

                <option value="" selected disabled>No hay libros añadidos</option>
            
            <?php else: ?>

                <option value="" selected disabled>Selecciona un libro:</option>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value=<?php echo e($book->id); ?> <?php echo e($book->disponible ? '' : 'disabled'); ?>><?php echo e($book->titulo); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
            <?php endif; ?>
        </select>
        
        <label for="fecha_devolucion">Fecha de devolución:</label>
        <input type="text" name="fecha_devolucion" required pattern="\d{2}/\d{2}/\d{4}" placeholder="dd/mm/YYYY" class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">

        <input type="submit" value="Añadir" class="mt-5 cursor-pointer text-lg py-2 px-4 text-white bg-emerald-600 rounded-xl hover:bg-emerald-800 hover:transition-all 0.3s">
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moren\Documents\Master EIP\9. Programaciones de Aplicaciones Web con Laravel\Actividades\actividad_3\resources\views/createPrestamo.blade.php ENDPATH**/ ?>