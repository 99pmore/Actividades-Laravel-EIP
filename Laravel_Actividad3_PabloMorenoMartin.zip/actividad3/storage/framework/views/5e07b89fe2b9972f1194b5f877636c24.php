<nav>
    <ul>
        <li><a href="/">Inicio</a></li>
        <li><a href="/showLibros">Ver libros</a></li>
        <li><a href="/showCreateLibro">Añadir libro</a></li>
    </ul>
</nav><?php /**PATH C:\Users\moren\Documents\Master EIP\9. Programaciones de Aplicaciones Web con Laravel\Actividades\actividad_2\resources\views/nav.blade.php ENDPATH**/ ?>