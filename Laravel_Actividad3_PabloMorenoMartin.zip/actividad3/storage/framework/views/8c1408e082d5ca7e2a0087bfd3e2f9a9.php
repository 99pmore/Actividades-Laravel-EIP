

<?php $__env->startSection('title', 'Editar Préstamo'); ?>

<?php $__env->startSection('content'); ?>

    <form action=<?php echo e(route('updatePrestamo')); ?> method="POST" class="w-full p-6 flex justify-center items-center gap-5 flex-col">
        <?php echo csrf_field(); ?>

        <label for="user_id">Usuario:</label>
        <select name="user_id" required class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">
            <?php if($users->isEmpty()): ?>

                <option value="" selected disabled>No hay usuarios</option>
            
            <?php else: ?>

                <option value="" selected disabled>Selecciona un usuario:</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($user->id == $loan->user_id): ?>
                        <option value=<?php echo e($user->id); ?> selected><?php echo e($user->name); ?></option>
                    <?php else: ?>
                        <option value=<?php echo e($user->id); ?>><?php echo e($user->name); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
            <?php endif; ?>
        </select>
        <label for="book_id">Libro:</label>
        <select name="book_id" class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">
            <?php if($books->isEmpty()): ?>

                <option>No hay libros añadidos</option>
            
            <?php else: ?>

                <option value="">Selecciona un libro:</option>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($book->id == $loan->book_id): ?>
                        <option value=<?php echo e($book->id); ?> selected><?php echo e($book->titulo); ?></option>
                    <?php else: ?>
                        <option value=<?php echo e($book->id); ?>><?php echo e($book->titulo); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
            <?php endif; ?>
        </select>
        <label for="fecha_prestamo">Fecha de préstamo:</label>
        <input type="text" name="fecha_prestamo" pattern="\d{2}/\d{2}/\d{4}" placeholder="dd/mm/YYYY" value="<?php echo e($loan->fecha_prestamo); ?>" class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">
        <label for="fecha_devolucion">Fecha devolución:</label>
        <input type="text" name="fecha_devolucion" pattern="\d{2}/\d{2}/\d{4}" placeholder="dd/mm/YYYY" value="<?php echo e($loan->fecha_devolucion); ?>" class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">
        <label for="disponible">Devuelto:</label>
        <input type="checkbox" name="disponible" <?php echo e($loan->devuelto ? 'checked' : ''); ?> class="w-5 h-5 border border-solid rounded-md border-emerald-600 outline-emerald-600">

        <input type="submit" value="Actualizar" class="mt-5 cursor-pointer text-lg py-2 px-4 text-white bg-emerald-600 rounded-xl hover:bg-emerald-800 hover:transition-all 0.3s">
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moren\Documents\Master EIP\9. Programaciones de Aplicaciones Web con Laravel\Actividades\actividad_3\resources\views/updatePrestamo.blade.php ENDPATH**/ ?>