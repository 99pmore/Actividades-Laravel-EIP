

<?php $__env->startSection('title', 'Libro añadido'); ?>

<?php $__env->startSection('content'); ?>

    <?php if( $id > 0 ): ?>
        <div class="flex justify-center items-center flex-col mt-20 gap-8">
            <h1 class="text-xl text-center font-bold">Libro añadido con éxito</h1>
        </div>
    <?php else: ?>
        <div class="flex justify-center items-center flex-col mt-20 gap-8">
            <h1 class="text-xl text-center font-bold">Ha ocurrido un error al añadir el libro</h1>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moren\Documents\Master EIP\9. Programaciones de Aplicaciones Web con Laravel\Actividades\actividad_2\resources\views/createLibro_OK.blade.php ENDPATH**/ ?>