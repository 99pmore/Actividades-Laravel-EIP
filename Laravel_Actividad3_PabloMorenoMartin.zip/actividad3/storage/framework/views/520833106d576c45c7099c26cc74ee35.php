<nav class="w-full p-4 flex justify-center items center bg-slate-700 text-white">
    <ul class="flex justify-center items-center gap-8">
        <li><a href="/" class="text-lg hover:text-xl hover:transition-all 0.2s ease-in-out">Inicio</a></li>
        <li><a href="/showLibros" class="text-lg hover:text-xl hover:transition-all 0.5s ease-in-out">Ver libros</a></li>
        <li><a href="/showCreateLibro" class="text-lg hover:text-xl hover:transition-all 0.5s ease-in-out">Añadir libro</a></li>
        <li><a href="/showPrestamos" class="text-lg hover:text-xl hover:transition-all 0.5s ease-in-out">Ver Préstamos</a></li>
    </ul>
</nav><?php /**PATH C:\Users\moren\Documents\Master EIP\9. Programaciones de Aplicaciones Web con Laravel\Actividades\actividad_2\resources\views/components/nav.blade.php ENDPATH**/ ?>