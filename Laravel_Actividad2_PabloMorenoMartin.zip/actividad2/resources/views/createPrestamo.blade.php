@extends('app')

@section('title', 'Añadir préstamo')

@section('content')

    <form action={{ route('createPrestamo') }} method="POST" class="w-full p-6 flex justify-center items-center gap-5 flex-col">
        @csrf

        <label for="user_id">Usuario:</label>
        <input type="number" name="user_id" required class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">
        <label for="book_id">Libro:</label>
        <select name="book_id" required class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">
            @if ($books->isEmpty())

                <option value="" selected disabled>No hay libros añadidos</option>
            
            @else

                <option value="" selected disabled>Selecciona un libro:</option>
                @foreach ($books as $book)
                    <option value={{ $book->id }} {{ $book->disponible ? '' : 'disabled' }}>{{ $book->titulo }}</option>
                @endforeach
        
            @endif
        </select>
        {{-- <label for="fecha_prestamo">Fecha de préstamo:</label>
        <input type="text" name="fecha_prestamo" required class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600"> --}}
        <label for="fecha_devolucion">Fecha de devolución:</label>
        <input type="text" name="fecha_devolucion" required pattern="\d{2}/\d{2}/\d{4}" placeholder="dd/mm/YYYY" class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">

        <input type="submit" value="Añadir" class="mt-5 cursor-pointer text-lg py-2 px-4 text-white bg-emerald-600 rounded-xl hover:bg-emerald-800 hover:transition-all 0.3s">
    </form>

@endsection