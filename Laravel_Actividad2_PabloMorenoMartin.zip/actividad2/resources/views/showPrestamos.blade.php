@extends('app')

@section('title', 'Ver préstamos')

@section('content')

    <div class="flex flex-col gap-12">
        <a href="/showCreatePrestamo" class="w-44 text-center text-lg py-2 px-4 text-white bg-emerald-600 rounded-xl hover:bg-emerald-800 hover:transition-all 0.3s">Añadir préstamo</a>

        <div>
            @if ($loans->isEmpty())

                <p>No hay préstamos</p>

            @else
            
                <table class="w-full border-spacing-6 border-separate">
                    <thead class="text-left">
                        <tr>
                            <th>Usuario</th>
                            <th>Libro</th>
                            <th>Fecha de préstamo</th>
                            <th>Fecha de devolución</th>
                            <th>Acción</th>
                            <th>Detalles</th>
                            <th>Marcar como devuelto</th>
                        </tr>
                    </thead>
                    <tbody>
                        @each('components.tablePrestamo', $loans, 'loan')
                    </tbody>
                </table>

            @endif
        </div>
    </div>

@endsection