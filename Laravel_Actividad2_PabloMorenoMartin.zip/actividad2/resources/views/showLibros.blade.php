@extends('app')

@section('title', 'Ver libros')

@section('content')

    @if ($books->isEmpty())

        <p>No hay libros añadidos</p>
        
    @else

        <table class="w-full border-spacing-6 border-separate">
            <thead class="text-left">
                <tr>
                    <th>Título</th>
                    <th>Autor</th>
                    <th>Año de publicación</th>
                    <th>Género</th>
                    <th>Disponible</th>
                    <th>Acción</th>
                    <th>Detalles</th>
                </tr>
            </thead>
            <tbody>
                @each('components.table', $books, 'book')
            </tbody>
        </table>

    @endif

@endsection