@extends('app')

@section('title', 'Añadir libro')

@section('content')

    <form action={{ route('createLibro') }} method="POST" class="w-full p-6 flex justify-center items-center gap-5 flex-col">
        @csrf

        <label for="titulo">Título:</label>
        <input type="text" name="titulo" required class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">
        <label for="autor">Autor:</label>
        <input type="text" name="autor" required class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">
        <label for="ano_publicacion">Año de publicación:</label>
        <input type="text" name="ano_publicacion" required class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">
        <label for="genero">Género:</label>
        <input type="text" name="genero" required class="w-1/4 px-3 py-1 border border-solid rounded-md border-emerald-600 outline-emerald-600">
        <label for="disponible">Disponible:</label>
        <input type="checkbox" name="disponible" required class="w-5 h-5 border border-solid rounded-md border-emerald-600 outline-emerald-600">

        <input type="submit" value="Añadir" class="mt-5 cursor-pointer text-lg py-2 px-4 text-white bg-emerald-600 rounded-xl hover:bg-emerald-800 hover:transition-all 0.3s">
    </form>

@endsection