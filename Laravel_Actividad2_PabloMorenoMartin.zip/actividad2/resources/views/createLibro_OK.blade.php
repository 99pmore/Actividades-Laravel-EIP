@extends('app')

@section('title', 'Libro añadido')

@section('content')

    @if ( $id > 0 )
        <div class="flex justify-center items-center flex-col mt-20 gap-8">
            <h1 class="text-xl text-center font-bold">Libro añadido con éxito</h1>
        </div>
    @else
        <div class="flex justify-center items-center flex-col mt-20 gap-8">
            <h1 class="text-xl text-center font-bold">Ha ocurrido un error al añadir el libro</h1>
        </div>
    @endif

@endsection