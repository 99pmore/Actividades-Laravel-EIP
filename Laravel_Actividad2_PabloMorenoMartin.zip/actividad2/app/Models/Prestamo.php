<?php

namespace App\Models;

use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Prestamo extends Model
{
    use HasFactory;

    public static function createPrestamo(Request $request) {

        $loan = new Prestamo();
        $loan->user_id = $request->input('user_id');
        $loan->book_id = $request->input('book_id');
        // $loan->fecha_prestamo = $request->input('fecha_prestamo');
        $fecha_now = now();
        $loan->fecha_prestamo = $fecha_now->format('d/m/Y');
        $loan->fecha_devolucion = $request->input('fecha_devolucion');
        $loan->devuelto = false;
        $loan->save();

        return $loan->id;
    }

    public static function showPrestamos() {
        return Prestamo::all();
    }

    public static function updatePrestamo($id, Request $request){
        $loan = Prestamo::find($id);
        $loan->user_id = $request->input('user_id');
        $loan->book_id = $request->input('book_id');
        $loan->fecha_prestamo = $request->input('fecha_prestamo');
        $loan->fecha_devolucion = $request->input('fecha_devolucion');
        $loan->save();
    }

    public static function deletePrestamo($id) {
        $loan = Prestamo::find($id);
        $loan->delete();
    }

    public static function findPrestamoID($id) {
        return Prestamo::find($id);
    }

    public static function endPrestamo($id) {

        $loan = Prestamo::find($id);
        $loan->devuelto = true;
        $fecha_now = now();
        $loan->fecha_devolucion = $fecha_now->format('d/m/Y');
        $loan->save();
    
        return $loan;
    }
}
